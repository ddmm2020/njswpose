# -*- coding: utf-8 -*-
# @File  : __init__.py
# @Author: ddmm
# @Date  : 2021/1/8
# @Desc  :

from __future__ import absolute_import
from .njswpose import *

name = 'njswpose'